# Vigenesia

UBSI - Vigenesia for null safety - Supported flutter version 3

## Overview
Mata kuliah Teknologi Web Service menggunakan model pembelajaran berbasis projek.

## Requirement
- Flutter sdk: '>=2.18.2 <3.0.0'
- Vs Code

## Installation
- Clone this project
```
git clone https://github.com/aaidant/vigenesia.git
```
- Open with your ide
- Run
```
flutter pub get
flutter run
```

## Author
Adan Aidan Teras - UBSI Kramat 98